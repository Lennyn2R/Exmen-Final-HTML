export default class Product {

    id;
    name;
    image;
    price;
    stock;

}